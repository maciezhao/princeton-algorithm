import edu.princeton.cs.algs4.StdIn;

public class Percolation {

    private final int[] lattice;

    private final int[] parent;

    private int openNum;

    private final int n;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Illegal N");
        }
        lattice = new int[n * n];
        parent = new int[n * n];
        for (int i = 0; i < parent.length; i++) {
            parent[i] = i;
        }
        openNum = 0;
        this.n = n;
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row <= 0 || col <= 0 || row > n || col > n) {
            throw new IllegalArgumentException("Out of bounds row " + row + " col " + col);
        }
        int x = row - 1;
        int y = col - 1;
        if (lattice[x * n + y] == 1) {
            return;
        }
        lattice[x * n + y] = 1;
        openNum++;
        // union
        if (x > 0 && lattice[(x - 1) * n + y] == 1) {
            union(x * n + y, (x - 1) * n + y);
        }
        if (x < n - 1 && lattice[(x + 1) * n + y] == 1) {
            union(x * n + y, (x + 1) * n + y);
        }
        if (y > 0 && lattice[x * n + y - 1] == 1) {
            union(x * n + y, x * n + y - 1);
        }
        if (y < n - 1 && lattice[x * n + y + 1] == 1) {
            union(x * n + y, x * n + y + 1);
        }
    }


    private void union(int x, int y) {
        int rootX = root(x);
        int rootY = root(y);
        if (rootX < rootY) {
            parent[rootY] = rootX;
        }
        else {
            parent[rootX] = rootY;
        }
    }

    private int root(int x) {
        while (parent[x] != x) {
            x = parent[parent[x]];
        }
        return x;
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row <= 0 || col <= 0 || row > n || col > n) {
            throw new IllegalArgumentException("Out of bounds row " + row + " col " + col);
        }
        return lattice[(row - 1) * n + (col - 1)] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row <= 0 || col <= 0 || row > n || col > n) {
            throw new IllegalArgumentException("Out of bounds row " + row + " col " + col);
        }
        int root = root((row - 1) * n + col - 1);
        return root >= 0 && root < n && lattice[root] == 1;
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openNum;

    }

    // does the system percolate?
    public boolean percolates() {
        int x = n - 1;
        for (int y = 0; y < n; y++) {
            if (isFull(x + 1, y + 1)) {
                return true;
            }
        }
        return false;
    }


    // test client (optional)
    public static void main(String[] args) {
        int n = StdIn.readInt();
        Percolation percolation = new Percolation(n);
        while (!StdIn.isEmpty()) {
            int x = StdIn.readInt();
            int y = StdIn.readInt();
            percolation.open(x, y);
            if (percolation.percolates()) {
                System.out.println(percolation.percolates());
                break;
            }
        }
    }
}
