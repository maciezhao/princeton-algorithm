import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private final double s;
    private final double mean;
    private final int trials;
    private final int n;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("Illegal Contructor Args");
        }
        double[] results = new double[trials];
        for (int i = 0; i < trials; i++) {
            Percolation perco = new Percolation(n);
            int[] rec = new int[n * n];
            for (int x = 0; x < n; x++) {
                for (int y = 0; y < n; y++) {
                    rec[x * n + y] = 1;
                }
            }
            while (!perco.percolates()) {
                int val = StdRandom.discrete(rec);
                rec[val] = 0;
                int x = val / n;
                int y = val - x * n;
                perco.open(x + 1, y + 1);
            }
            results[i] = (double) perco.numberOfOpenSites() / (double) (n * n);
        }

        this.n = n;
        this.trials = trials;
        this.mean = StdStats.mean(results);
        this.s = StdStats.stddev(results);
    }

    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return s;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean - 1.96 * s / Math.sqrt(trials);
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean + 1.96 * s / Math.sqrt(trials);
    }

    // test client (see below)
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        PercolationStats stats = new PercolationStats(n, trials);
        System.out.println("mean                    = " + stats.mean());
        System.out.println("stddev                  = " + stats.stddev());
        System.out.println("95% confidence interval =" + String.format(" [%f, %f]",
                                                                       stats.confidenceLo(),
                                                                       stats.confidenceHi()));
    }
}
